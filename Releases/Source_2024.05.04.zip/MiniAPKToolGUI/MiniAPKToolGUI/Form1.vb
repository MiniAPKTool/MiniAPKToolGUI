﻿Imports System.IO

Public Class Form1
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '######################################################################
        '#                     Check if JavaJDK installed                     #
        '######################################################################
        Dim processInfo As New ProcessStartInfo("cmd.exe", "/c javac")
        processInfo.RedirectStandardOutput = True
        processInfo.UseShellExecute = False
        processInfo.CreateNoWindow = True

        Dim process As Process = New Process()
        process.StartInfo = processInfo
        process.Start()

        Dim output As String = process.StandardOutput.ReadToEnd()
        process.WaitForExit()

        If Not output.Contains("--") Then
            MsgBox("To run the program you need to install Java JDK. To do this, follow the link, download and install the most current version of the Java JDK. After that restart this program. If the installation is successful, this window will not be shown." & vbCrLf & vbCrLf & "https://www.oracle.com/de/java/technologies/downloads/")
        End If

        '######################################################################
        '#                              Options file                          #
        '######################################################################
        If Not System.IO.File.Exists(Application.StartupPath & "\MiniAPKToolGUI.ini") Then                       'if options file not exist
            System.IO.File.Create(Application.StartupPath & "\MiniAPKToolGUI.ini").Dispose()                     'create options file
            Dim createText() As String = {"", ""}                                                                'write empty lines in options file
            System.IO.File.WriteAllLines(Application.StartupPath & "\MiniAPKToolGUI.ini", createText)
        End If

        '######################################################################
        '#                              Load options                          #
        '######################################################################
        '###########
        '# apktool #
        '###########

        Dim Lines() As String = System.IO.File.ReadAllLines(Application.StartupPath & "\MiniAPKToolGUI.ini")
        If Lines(0) = "" Then TextBox1.Text = "Browse or Drag&Drop apktool_*.*.*.jar  ||  https://apktool.org/docs/install/"
        'search for apktool in application folder
        Try
            Dim filesInAppFolder As String() = Directory.GetFiles(Application.StartupPath)
            For Each file As String In filesInAppFolder
                If file.Contains("apktool") AndAlso Path.GetExtension(file) = ".jar" Then
                    TextBox1.Text = file
                End If
            Next
        Catch ex As Exception
        End Try
        If Lines(0) <> "" Then TextBox1.Text = Lines(0)

        '###################
        '# uber-apk-signer #
        '###################

        If Lines(1) = "" Then TextBox2.Text = "Browse or Drag&Drop uber-apk-signer-*.*.*.jar  ||  https://github.com/patrickfav/uber-apk-signer"
        'search for uber-apk-signer in application folder
        Try
            Dim filesInAppFolder As String() = Directory.GetFiles(Application.StartupPath)
            For Each file As String In filesInAppFolder
                If file.Contains("uber-apk-signer") AndAlso Path.GetExtension(file) = ".jar" Then
                    TextBox2.Text = file
                End If
            Next
        Catch ex As Exception
        End Try
        If Lines(1) <> "" Then TextBox2.Text = Lines(1)

        '######################################################################
        '#                             Drag&Drop                              #
        '######################################################################
        TextBox1.AllowDrop = True
        TextBox2.AllowDrop = True
        PictureBox1.AllowDrop = True
        PictureBox2.AllowDrop = True
        PictureBox3.AllowDrop = True
        PictureBox4.AllowDrop = True

        '######################################################################
        '#                              Rest                                  #
        '######################################################################
        PictureBox5.Width = 32
        PictureBox5.Height = 32
        PictureBox5.Left = Me.ClientSize.Width / 2 - PictureBox5.Width / 2
        PictureBox5.Top = TextBox2.Top + TextBox2.Height + 2
        PictureBox5.Visible = False
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        '######################################################################
        '#                       Change oprions file                          #
        '######################################################################
        Dim Lines() As String = System.IO.File.ReadAllLines(Application.StartupPath & "\MiniAPKToolGUI.ini")
        Lines(0) = TextBox1.Text
        Lines(1) = TextBox2.Text
        System.IO.File.WriteAllLines(Application.StartupPath & "\MiniAPKToolGUI.ini", Lines)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        '######################################################################
        '#                            Form design                             #
        '######################################################################
        TextBox1.Width = Me.ClientSize.Width - Button1.Width - 30
        TextBox2.Width = TextBox1.Width

        PictureBox1.Top = Button2.Top + Button2.Height + 24

        PictureBox1.Width = (Me.ClientSize.Width - 12 * 5) / 4
        PictureBox1.Height = PictureBox1.Width

        PictureBox2.Top = PictureBox1.Top
        PictureBox2.Left = PictureBox1.Left + PictureBox1.Width + 12
        PictureBox2.Width = PictureBox1.Width
        PictureBox2.Height = PictureBox1.Width

        PictureBox3.Top = PictureBox1.Top
        PictureBox3.Left = PictureBox1.Left + PictureBox1.Width + 12 + PictureBox2.Width + 12
        PictureBox3.Width = PictureBox1.Width
        PictureBox3.Height = PictureBox1.Width

        PictureBox4.Top = PictureBox1.Top
        PictureBox4.Left = PictureBox1.Left + PictureBox1.Width + 12 + PictureBox2.Width + 12 + PictureBox3.Width + 12
        PictureBox4.Width = PictureBox1.Width
        PictureBox4.Height = PictureBox1.Width

        If (PictureBox1.Top + PictureBox1.Height + 12) > Me.ClientSize.Height Then
            Me.Height = PictureBox1.Top + PictureBox1.Height + 60
        End If

    End Sub

    '######################################################################
    '#                     Path assignment via buttons                    #
    '######################################################################
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        OpenFileDialog1.Filter = "Java files|*.jar"
        If OpenFileDialog1.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK Then
            TextBox1.Text = OpenFileDialog1.FileName
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        OpenFileDialog1.Filter = "Java files|*.jar"
        If OpenFileDialog1.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK Then
            TextBox2.Text = OpenFileDialog1.FileName
        End If
    End Sub

    Private Sub TextBox1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.DoubleClick
        TextBox1.Text = "Browse or Drag&Drop apktool_*.*.*.jar  ||  https://apktool.org/docs/install/"
    End Sub

    Private Sub TextBox2_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox2.DoubleClick
        TextBox2.Text = "Browse or Drag&Drop uber-apk-signer-*.*.*.jar  ||  https://github.com/patrickfav/uber-apk-signer"
    End Sub

    '######################################################################
    '#                     Path assignment via Drop&Down                  #
    '######################################################################
    Private Sub TextBox1_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles TextBox1.DragEnter
        If (e.Data.GetDataPresent(DataFormats.FileDrop)) Then
            e.Effect = DragDropEffects.Copy
        End If
    End Sub
    Private Sub TextBox1_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles TextBox1.DragDrop
        If Path.GetExtension(e.Data.GetData(DataFormats.FileDrop)(0)) = ".jar" Then
            TextBox1.Text = e.Data.GetData(DataFormats.FileDrop)(0)
        End If
    End Sub

    Private Sub TextBox2_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles TextBox2.DragEnter
        ' Check if the dragged item is a file
        If (e.Data.GetDataPresent(DataFormats.FileDrop)) Then
            e.Effect = DragDropEffects.Copy
        End If
    End Sub
    Private Sub TextBox2_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles TextBox2.DragDrop
        If Path.GetExtension(e.Data.GetData(DataFormats.FileDrop)(0)) = ".jar" Then
            TextBox2.Text = e.Data.GetData(DataFormats.FileDrop)(0)
        End If
    End Sub

    '######################################################################
    '#                    Decompile apk via Drop&Down                     #
    '######################################################################
    Private Sub PictureBox1_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles PictureBox1.DragEnter
        If (e.Data.GetDataPresent(DataFormats.FileDrop)) Then
            e.Effect = DragDropEffects.Copy
        End If
    End Sub
    Private Sub PictureBox1_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles PictureBox1.DragDrop
        If Path.GetExtension(e.Data.GetData(DataFormats.FileDrop)(0)) = ".apk" Then

            PictureBox5.Visible = True
            PictureBox5.Refresh()

            Dim sourceFolder As String = Application.StartupPath() & "\" & Path.GetFileNameWithoutExtension(e.Data.GetData(DataFormats.FileDrop)(0))
            Dim destinationFolder As String = Path.GetDirectoryName(e.Data.GetData(DataFormats.FileDrop)(0)) & "\" & Path.GetFileNameWithoutExtension(e.Data.GetData(DataFormats.FileDrop)(0))


            Dim processInfo As New ProcessStartInfo("cmd.exe", " /c " & TextBox1.Text & " d " & Chr(34) & e.Data.GetData(DataFormats.FileDrop)(0) & Chr(34))
            processInfo.RedirectStandardOutput = True
            processInfo.UseShellExecute = False
            processInfo.CreateNoWindow = True

            Dim output As String = ""
            Dim process As New Process()

            Dim thread As New Threading.Thread(Sub()
                                                   process.StartInfo = processInfo
                                                   process.Start()
                                                   output = process.StandardOutput.ReadToEnd()
                                                   process.WaitForExit()
                                                   If process.HasExited Then
                                                       If Directory.Exists(destinationFolder) Then
                                                           Directory.Delete(destinationFolder, True)
                                                       End If
                                                       Directory.Move(sourceFolder, destinationFolder)
                                                       PictureBox5.Invoke(Sub()
                                                                              PictureBox5.Visible = False
                                                                              PictureBox5.Refresh()
                                                                          End Sub)
                                                       MsgBox("Decompilation completed")

                                                   End If
                                               End Sub)
            thread.Start()

        End If

    End Sub

    '######################################################################
    '#                      Build apk via Drop&Down                       #
    '######################################################################
    Private Sub PictureBox2_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles PictureBox2.DragEnter
        ' Check if the dragged item is a folder
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            Dim files() As String = CType(e.Data.GetData(DataFormats.FileDrop), String())
            If System.IO.Directory.Exists(files(0)) Then
                e.Effect = DragDropEffects.Copy
            End If
        End If
    End Sub
    Private Sub PictureBox2_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles PictureBox2.DragDrop
        PictureBox5.Visible = True
        PictureBox5.Refresh()

        ' Get the dropped folder path
        Dim files() As String = CType(e.Data.GetData(DataFormats.FileDrop), String())
        Dim folderPath As String = files(0)

        Dim sourceFile As String = Application.StartupPath() & "\" & Path.GetFileName(folderPath) & "_built.apk"
        Dim destinationFile As String = Path.GetDirectoryName(folderPath) & "\" & Path.GetFileName(folderPath) & "_built.apk"

        Dim processInfo As New ProcessStartInfo("cmd.exe", " /c " & TextBox1.Text & " b " & Chr(34) & folderPath & Chr(34) & " -o " & Path.GetFileName(folderPath) & "_built.apk")
            processInfo.RedirectStandardOutput = True
            processInfo.UseShellExecute = False
            processInfo.CreateNoWindow = True

            Dim output As String = ""
            Dim process As New Process()

        Dim thread As New Threading.Thread(Sub()
                                               process.StartInfo = processInfo
                                               process.Start()
                                               output = process.StandardOutput.ReadToEnd()
                                               process.WaitForExit()
                                               If process.HasExited Then
                                                   If File.Exists(destinationFile) Then
                                                       File.Delete(destinationFile)
                                                   End If
                                                   File.Move(sourceFile, destinationFile)
                                                   PictureBox5.Invoke(Sub()
                                                                          PictureBox5.Visible = False
                                                                          PictureBox5.Refresh()
                                                                      End Sub)
                                                   MsgBox("Building completed")
                                               End If
                                           End Sub)
            thread.Start()

    End Sub

    '######################################################################
    '#                  Build apk via Drop&Down (AAPT2)                   #
    '######################################################################
    Private Sub PictureBox3_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles PictureBox3.DragEnter
        ' Check if the dragged item is a folder
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            Dim files() As String = CType(e.Data.GetData(DataFormats.FileDrop), String())
            If System.IO.Directory.Exists(files(0)) Then
                e.Effect = DragDropEffects.Copy
            End If
        End If
    End Sub
    Private Sub PictureBox3_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles PictureBox3.DragDrop
        PictureBox5.Visible = True
        PictureBox5.Refresh()

        ' Get the dropped folder path
        Dim files() As String = CType(e.Data.GetData(DataFormats.FileDrop), String())
        Dim folderPath As String = files(0)

        Dim sourceFile As String = Application.StartupPath() & "\" & Path.GetFileName(folderPath) & "_built.apk"
        Dim destinationFile As String = Path.GetDirectoryName(folderPath) & "\" & Path.GetFileName(folderPath) & "_built.apk"

        Dim processInfo As New ProcessStartInfo("cmd.exe", " /c " & TextBox1.Text & " b " & Chr(34) & folderPath & Chr(34) & " -o " & Path.GetFileName(folderPath) & "_built.apk --use-aapt2")
        processInfo.RedirectStandardOutput = True
        processInfo.UseShellExecute = False
        processInfo.CreateNoWindow = True

        Dim output As String = ""
        Dim process As New Process()

        Dim thread As New Threading.Thread(Sub()
                                               process.StartInfo = processInfo
                                               process.Start()
                                               output = process.StandardOutput.ReadToEnd()
                                               process.WaitForExit()
                                               If process.HasExited Then
                                                   If File.Exists(destinationFile) Then
                                                       File.Delete(destinationFile)
                                                   End If
                                                   File.Move(sourceFile, destinationFile)
                                                   PictureBox5.Invoke(Sub()
                                                                          PictureBox5.Visible = False
                                                                          PictureBox5.Refresh()
                                                                      End Sub)
                                                   MsgBox("AAPT2 Building completed")
                                               End If
                                           End Sub)
        thread.Start()

    End Sub

    '######################################################################
    '#                  Signing apk via Drop&Down                         #
    '######################################################################
    Private Sub PictureBox4_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles PictureBox4.DragEnter
        If (e.Data.GetDataPresent(DataFormats.FileDrop)) Then
            e.Effect = DragDropEffects.Copy
        End If
    End Sub

    Private Sub PictureBox4_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles PictureBox4.DragDrop
        If Path.GetExtension(e.Data.GetData(DataFormats.FileDrop)(0)) = ".apk" Then

            PictureBox5.Visible = True
            PictureBox5.Refresh()

            ' Create the "Temp" folder
            Directory.CreateDirectory(Application.StartupPath() & "\Temp")

            ' Wait until the folder is created
            While Not Directory.Exists(Application.StartupPath() & "\Temp")
                System.Threading.Thread.Sleep(500)
            End While

            ' Copy file to "Temp" folder
            Dim sourceFile As String = e.Data.GetData(DataFormats.FileDrop)(0)
            Dim destinationFile As String = Application.StartupPath() & "\Temp\" & Path.GetFileName(e.Data.GetData(DataFormats.FileDrop)(0))

            File.Copy(sourceFile, destinationFile)

            ' Wait until the copying process is complete
            Do While File.Exists(destinationFile & ".tmp")
                System.Threading.Thread.Sleep(500)
            Loop

            Dim processInfo As New ProcessStartInfo("cmd.exe", " /c " & TextBox2.Text & " --apks " & Chr(34) & Path.GetDirectoryName(destinationFile) & Chr(34))
            processInfo.RedirectStandardOutput = True
            processInfo.UseShellExecute = False
            processInfo.CreateNoWindow = True

            Dim output As String = ""
            Dim process As New Process()

            Dim thread As New Threading.Thread(Sub()
                                                   process.StartInfo = processInfo
                                                   process.Start()
                                                   output = process.StandardOutput.ReadToEnd()
                                                   process.WaitForExit()
                                                   If process.HasExited Then

                                                       ' Find signed file
                                                       Dim files As String() = System.IO.Directory.GetFiles(Path.GetDirectoryName(destinationFile), "*.apk")
                                                       For Each file As String In files
                                                           If file.Contains("igned.apk") Then
                                                               ' Move signed file to source folder
                                                               System.IO.File.Move(file, Path.GetDirectoryName(sourceFile) & "\" & Path.GetFileName(file))
                                                           End If
                                                       Next

                                                       If Directory.Exists(Application.StartupPath() & "\Temp") Then
                                                           Directory.Delete(Application.StartupPath() & "\Temp", True)
                                                       End If

                                                       PictureBox5.Invoke(Sub()
                                                                              PictureBox5.Visible = False
                                                                              PictureBox5.Refresh()
                                                                          End Sub)
                                                       MsgBox("Signature completed")

                                                   End If
                                               End Sub)
            thread.Start()

        End If

    End Sub

End Class








